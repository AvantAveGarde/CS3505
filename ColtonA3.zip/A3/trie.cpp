#include "trie.h"
#include "node.h"

void Trie::addWord(std::string i_word){
  //Converts string to upper case so no need to worry about sensitivity.
  for (auto & c: i_word) c = toupper(c);

  insertToTrie(i_word, root, 0);
}

void Trie::insertToTrie(std::string i_word, Node& i_node, int i_letterIndex = 0){
  //Break Case
  if(i_letterIndex < i_word.length()){
    //Index maps to our i_node's children which are node pointers.
    int nodeArrayIndex = (int)i_word[i_letterIndex] - 65;

    if(i_node.children[nodeArrayIndex] == 0){
      //If at the end of a word, set letter to true
      if(i_letterIndex == i_word.length() - 1){
        Node newNode = new Node(true);
        i_node.children[nodeArrayIndex] = &newNode;
        std::cout << "(New) (True) " << i_word[i_letterIndex] << ":" << i_node.children[nodeArrayIndex] << std::endl;
      }
      else{
        Node newNode = new Node(false);
        i_node.children[nodeArrayIndex] = &newNode;
        std::cout << "(New) " << i_word[i_letterIndex] << ":" << i_node.children[nodeArrayIndex] << std::endl;

        insertToTrie(i_word, newNode, i_letterIndex + 1);
      }
    }
    else{
      Node newNode = *(i_node.children[nodeArrayIndex]);
      std::cout << i_word[i_letterIndex] << ":" << i_node.children[nodeArrayIndex] << std::endl;
      insertToTrie(i_word, newNode, i_letterIndex + 1);
    }
  }
}

bool Trie::isWord(std::string word){

}

std::vector<std::string> Trie::allWordsStartingWithPrefix(char letter){

}


Trie::Trie(){
  root = Node();
}

//Rule of Three, Constructor, Copy Constructor & Destructor

//Copy Constructor - Copies wordArray and the root node
Trie::Trie(const Trie& i_Trie){
  int len = i_Trie.wordArray.size();
  std::vector<std::string> wordArray;
  wordArray = i_Trie.wordArray;
  root = i_Trie.root;
}
//Assignment Constructor, using copy swap idiom, returns a reference to the
//now swapped Trie object.
Trie & Trie::operator=(Trie i_Trie){
  std::swap(wordArray, i_Trie.wordArray);
  std::swap(root, i_Trie.root);
  return *this;
}

Trie::~Trie(){
  std::cout << "Destructed" << std::endl;
}
