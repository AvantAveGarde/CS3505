#ifndef NODE_H
#define NODE_H

class Node{
public:
  Node* children[26];
  bool isValidWord;

  Node();
  Node(bool i_isValidWord);
  void setValid();
  bool isValid();
};
#endif
