#include "node.h"

bool Node::isValid(){
  return isValidWord;
}

Node::Node(bool i_endOfWord){
  isValidWord = i_endOfWord;
  for(int i=0; i < 26; i++){
    children[i] = nullptr;
  }
}
void Node::setValid(){
  isValidWord = true;
}

Node::Node(){

}
