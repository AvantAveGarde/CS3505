#include "trie.h"
#include <iostream>

int main(){
  Trie testTrie = Trie();
  testTrie.addWord("colton");
  testTrie.addWord("coltonlee");
  //std::cout << "All is good in the hood! " << std::endl;

  return 0;
}
